//
//  ViewController.swift
//  MapCombine
//
//  Created by Yi Hwei Huang on 2018/10/2.
//  Copyright © 2018年 tw.iii.org. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase
import FirebaseStorage
import FirebaseAuth

class SpotAddController: UIViewController , CLLocationManagerDelegate , UINavigationControllerDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UISearchBarDelegate,MKMapViewDelegate{
    
    
    
    @IBOutlet weak var SearchBarMap: UISearchBar!
    @IBOutlet weak var MapView: MKMapView!
    
    // VARIABLES
    let locationManager = CLLocationManager()
    //    var addressArray=[String]()
    var imgPicked=UIImage()
    var anno = MKPointAnnotation()
    let myImagePicker: UIImagePickerController = UIImagePickerController()
    let geocoder = CLGeocoder()
    var address:String=""
    var pickPhoto=UIButton()
    var addSpotBtn=UIButton(type: .custom)
    var spotDescri:String=""
    var lat:String=""
    var lon:String=""
    var InfoDict:String=""
    var addressArray:[String]=[]
    var mainAddress:String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        locationManager = CLLocationManager()
        //        locationManager.delegate = self
        Auth.auth().signInAnonymously(completion: nil)
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()
        SearchBarMap.delegate = self as? UISearchBarDelegate
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    
    // MARK: CLLocation Manager Delegate
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while get location \(error)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if pickPhoto.tag==101{
            pickPhoto.setImage(imgPicked, for: .normal)
        }
        
    }
    
    
    
    @objc func btnAdd_Click(_ sender:UIButton) {
        //@objc func buttonPress(_ sender:UIButton)
        
        if sender.tag==105{
            //            print("====tag 105 press once")
            let SpotAdd_AlertController=UIAlertController(title: "新增景點描述", message: "可自由輸入景點描述(限30字)\n或直接新增景點", preferredStyle: .alert)
            
            
            SpotAdd_AlertController.addTextField { (txtspotDecri)  in
                txtspotDecri.placeholder = "請輸入景點描述，限30字以下...."
                txtspotDecri.frame=CGRect(x: 10.0, y: 10.0, width: 70.0, height: 30.0)
                self.spotDescri=txtspotDecri.text!
            }
            
            let cancelAction=UIAlertAction(title: "取消", style: UIAlertActionStyle.cancel, handler: {
                (action) -> Void in
                //cancel
            })
            
            let okAction = UIAlertAction(title: "送出", style: UIAlertActionStyle.default, handler: {
                //closure閉包 -->handler is the keyword-->這是一段可以寫獨立的程式的地方，算是多重執行續的一部分
                (action) -> Void in
                let txtSpotDescri = SpotAdd_AlertController.textFields?[0].text
                if txtSpotDescri == nil{
                    self.spotDescri=""
                }
                else{
                    self.spotDescri=txtSpotDescri!
                    print("okaction===>",self.spotDescri)
                }
                //------->執行送出資料到伺服器<-------------
                self.SaveTheSpot()
                //                var imgUpload=ImageUploadViewController.imagePickerController(SpotAddController.imgPicked)
                
            })
            
            
            
            //add button on alertview to controller
            
            SpotAdd_AlertController.addAction(okAction)
            SpotAdd_AlertController.addAction(cancelAction)
            
            
            self.present(SpotAdd_AlertController,animated: true,completion: nil)
            //
            //
        }
        
    }
    
    
    
    
    func SaveTheSpot(){
        ///原本要做資料傳送的段落
        
        
        if SearchBarMap.text != nil{
            //*******************記得修改代值問題
            
            
            let PostData:[String:Any]=["PosX":"\(lon)","PosY":"\(lat)","Address":"\(mainAddress)","Name":"\(SearchBarMap.text!)","Description":"\(spotDescri)"]
            
            
                        print(PostData,"========Post data=======")
            
            if let token=UserDefaults.standard.value(forKeyPath: "token") as? String{
                //                print(token,"=======>token in spot upload")
                
                let strurl:String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot?accessuid=2"
                
                //                    print("=======data is go to server=======")
                //"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot"
                let strPerEsc: String = strurl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
                let myURL = URL(string: strPerEsc)!
                let SessionConfig = URLSessionConfiguration.default
                let session = URLSession(configuration: SessionConfig, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: myURL)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: PostData, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                    }
                    
                    if let data = data{ //body裡面的東西
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
            }///原本段落結束
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        //確認選取
        let tookImage: UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        
        
//
//                // 設定儲存位置 存在pic子目錄
//                let storageRef = Storage.storage().reference().child("pic")
//
//                // 從info中取得選取影像 並轉型為UIImage
//                var image:UIImage?
//                if let myImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
//                    image = myImage
//                }
//
//                // 設定上傳檔案名
//                var filename = "image.JPG"
//                if let url = info[UIImagePickerControllerImageURL] as? URL{
//                    print(url,"======>url")
//                    filename = url.lastPathComponent //url最後一個Component就是檔案名稱
//                    print(filename,"=====>lastpath")
//                }
//
//                // 取得目前使用者 ID
//                if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
//                    if let data = UIImageJPEGRepresentation(image!, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
//
//                        //建立中介資料
//                        let myMetadata = StorageMetadata()
//
//                        myMetadata.contentType = "image/jpeg" //***轉為圖擋
//
//                        myMetadata.customMetadata = ["myKey":"myValue"] //可自訂metadata 將要的資訊設在Storage中
//
//        //                uploadStatus.isHidden = false //上傳前顯示進度條
//
//                        //print(myMetadata)
//
//                        //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
//                        let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in //完成時會回傳: 真正完成的metadata跟Error
//
//        //                    self.uploadStatus.isHidden = true //上傳成功與否 都將進度條隱藏
//
//                            if  error == nil{
//
//                                //若上傳成功
//                                let dataRef = Database.database().reference().child("pic")
//                                //print(metadata)
//
//                                storageRef.child(theUid).child(filename).downloadURL(completion: {
//
//                                    (url, error) in
//
//                                    //print("\(url)--------")
//                                    if error != nil {
//
//                                        return
//                                    } else {
//
//                                        let url = url?.absoluteString //＊＊＊取得URL的字串
//                                        print("======urlabsolute string ====",url)
//                                        let value = ["uid":theUid,"link":url]
//
//                                        dataRef.childByAutoId().setValue(value)
//
//
//                                        UserDefaults.standard.set(url, forKey: "firebase_URL") //用UserDefaults將要POST到資料庫的url存進去
//                                        UserDefaults.standard.synchronize() //同步
//                                    }
//                                })
//
//                                ///////寫入到Server///////////
//                                //let user = Auth.auth().currentUser
//
//
//                                let uploaderId = theUid
//                                //                        var path:String?
//                                //                        dataRef.observe(.childAdded) { (snapshot) in
//                                //
//                                //                            let link = snapshot.childSnapshot(forPath: "link").value as! String
//                                //                            path = link
//                                //                        }
//
//                                //用UserDefaults將要POST到資料庫的url取出
//                                let firebaseURL = UserDefaults.standard.value(forKey: "firebase_URL") as! String
//
//                                print(firebaseURL,"測試用firebaseURL")
//
//                                let postdata:[String: Any] = ["UploaderUid":uploaderId,"Path":firebaseURL] //注意：型別 與 欄位名稱 是否與資料庫一致
//
//                                let url = URL(string: "http://Testpmtobe-env.cvxrvfa7jm.ap-northeast-1.elasticbeanstalk.com/api/UploadImageAPP") //用我寫的api
//
//                                let config = URLSessionConfiguration.default
//                                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
//                                var request = URLRequest(url: url!)
//
//                                request.httpMethod = "POST"
//                                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
//
//                                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
//                                request.httpBody = httpbody
//
//                                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
//
//                                    if let response = response{
//                                        print(response,"=====這是URLResponse：")
//                                    }
//                                    if let data = data{
//                                        do{
//                                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
//
//                                            print(json,"====這是json：")
//                                        }catch{
//
//                                            print(error,"====這是error：")
//
//                                        }
//                                    }
//                                })
//                                dataTask.resume()
//
//
//                                //                        let value = ["uid":theUid,"link":(metadata?.downloadURL())!.absoluteString]//(待查詢)link：存回傳的metadata中的下載位置
//                                //dataRef.childByAutoId().setValue(value)
//
//
//                            }else{
//                                //若上傳失敗 印出錯誤
//                                print(error?.localizedDescription)
//                            }
//                        }
//
//                    }
//                }
//
//
        
        pickPhoto.tag=101
        imgPicked = tookImage
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //取消
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        SearchBarMap.resignFirstResponder()
        
        //address --> lat,lon
        geocoder.geocodeAddressString(SearchBarMap.text!) { (placemarks:[CLPlacemark]?, error:Error?) in
            if error == nil {
                
                //                print(self.geocoder)
                let placemark = placemarks?.first
                
                self.anno.coordinate = (placemark?.location?.coordinate)!
                
                self.lat=String(format: "%f", self.anno.coordinate.latitude)
                self.lon=String(format: "%f", self.anno.coordinate.longitude)
                print(self.lat,self.lon,"====>")
                
                self.anno.title = self.SearchBarMap.text!
                
                let span = MKCoordinateSpanMake(0.075, 0.075)
                let region = MKCoordinateRegion(center: self.anno.coordinate, span: span)
                
                
                let location=CLLocation(latitude: self.anno.coordinate.latitude, longitude: self.anno.coordinate.longitude)
                
                
                //lat,lon-->address
                
                self.MapView.setRegion(region, animated: true)
                self.MapView.addAnnotation(self.anno)
                self.MapView.selectAnnotation(self.anno, animated: true)
                
                //轉譯地址
                self.reversGeocoding(lat:self.lat,lon:self.lon)
               
            }
            else{
                print(error?.localizedDescription ?? "error")
            }
            
        }
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation{
            print("annotation is MKUserLocation")
            return nil
        }
        
        var annView=mapView.dequeueReusableAnnotationView(withIdentifier: "Pin")
        if (annView==nil){
            annView=MKPinAnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            //            print("mapView.dequeueReusableAnnotationView")
        }
        
        
        //callout panel
        if (annotation.title)!==SearchBarMap.text!{
            
            
            pickPhoto.frame=CGRect(x: 10.0, y: 10.0, width:40.0 , height: 40.0)
            pickPhoto.setImage(#imageLiteral(resourceName: "gallery2"), for: .normal)
            pickPhoto.tag=100
            pickPhoto.addTarget(self, action: #selector(SpotAddController.pickPhoto_buttonPress), for: UIControlEvents.touchUpInside)
            annView?.leftCalloutAccessoryView=pickPhoto
            
            let addresslbl=UILabel()
            addresslbl.numberOfLines=3
            addresslbl.frame=CGRect(x: 5.0, y: 5.0, width: 40.0, height: 40.0)
            addresslbl.text=self.address
            addresslbl.font=addresslbl.font.withSize(10)
            annView?.detailCalloutAccessoryView=addresslbl
            
            //right add btn
            
            addSpotBtn.setImage(#imageLiteral(resourceName: "plus-symbol"), for: .normal)
            addSpotBtn.frame=CGRect(x: 40.0, y: 75.0, width: 15.0, height: 15.0)
            addSpotBtn.tag=105
            addSpotBtn.addTarget(self, action: #selector(SpotAddController.btnAdd_Click(_:)), for: UIControlEvents.touchUpInside)
            annView?.rightCalloutAccessoryView=addSpotBtn
            
            
        }
        annView?.canShowCallout=true
        return annView
    }
    
    @objc func pickPhoto_buttonPress(_ sender:UIButton){
        if sender.tag==100{
            myImagePicker.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
            myImagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            
            self.present(myImagePicker, animated: true, completion: nil)
        }
    }
    
    func reversGeocoding(lat:String,lon:String){
        print("======myfunc reversegeocoding =========")
        //建立檔案路徑
        let strURL: String = "https://maps.googleapis.com/maps/api/geocode/json?latlng=\(lat),\(lon)&key=api_key&language=zh_TW"
        //URL結尾要加上參數：&language=zh_TW（因為用App存取時 Google無法判斷你的語言  所以要標示上語言種類 不然預設為英文）
//        print(strURL)
        
        //建立連線的物件
        let strPerEsc:String=strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let myURL: URL = URL(string: strPerEsc)!
        let mySessionConfig = URLSessionConfiguration.default
        let mySession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        
        //建立request物件
        var myRequest = URLRequest(url: myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data: Data?, response: URLResponse?, error: Error?) -> Void in
            
            if error == nil {
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("http狀態碼:\(statusCode)")
                print("共下載:\(data!.count)bytes")
                print("===>data")
                print(data as Any)
                
                ////解析JSON＊＊註：因為value有很多種可能  所以建議都用[String: Any]的形式表示Dictionary
                do {
                    let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any] //用.jsonObject()方法可得到一個Dictionary物件 但還要再做隱含轉換as! 編譯器才能確定是Dictionary
                    
                    //註：解析完第一層 會回傳status跟results
                    
                    print("查詢狀態:\(resDict["status"]!)")
                    
                    
                    let arrayResult: [[String: Any]] = resDict["results"] as! [[String:Any]]
                    
                    
                    //                   var dict=[String:String]()
                    for myDict: [String: Any] in arrayResult {
                        let address=myDict["formatted_address"] as! String
                        self.addressArray.append(address)
                        
                        //    self.str = myDict["formatted_address"] as! String
                        //    self.str = "\n"
                        print("查到的地址是:\(myDict["formatted_address"]!)")
                        //                        print("place_id:\(myDict["place_id"]!)")
                        //                        print(self.addressArray,"=====addressArray")
                    }
                    
                    //存第一筆地址起來
                    if self.addressArray.first == nil{
                        self.mainAddress="can't get address"
                    }
                    else{
                        self.mainAddress=self.addressArray.first!
                    }
                    
                    print(self.mainAddress,"======main address")
                }
                catch {
                    print("解析錯誤:\(error)")
                }
                ////////////
            } else {
                print("錯誤:\(String(describing: error?.localizedDescription))")
            }
        })
        myDataTask.resume()
        
    }
    
    
    
    
    
   
    
    
    
}





