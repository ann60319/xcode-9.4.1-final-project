//
//  UserInfo.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/8.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation

struct Photographer{
    var Uid:Int?
    var GUID:String?
    var ShowName:String?
    var Email:String?
    var Phone:String?
    var PhotoType:String?
    var AcceptStyle:String?
    var AcceptPurpose:String?
    var WorkLocation:String?
    var Address:String?
    var ContactWay:String?
    var Introduction:String?
    var ProfileUrl:String?
    var History:Int?
    var MinPay:String?
    var AvgScore:String?
    var ClickCount:Int?
    var IsCertificated:String?
    var IsBlocked:String?
    var Visible:Int?
    var AcceptRequest:Int?
}

struct PUser:Decodable{
    var data:[PInfo]?
}

struct PInfo:Decodable {
    var Uid:Int?
    var GUID:String?
    var ShowName:String?
    var Email:String?
    var Phone:String?
    var PhotoType:String?
    var AcceptStyle:String?
    var AcceptPurpose:String?
    var WorkLocation:String?
    var Address:String?
    var ContactWay:String?
    var Introduction:String?
    var ProfileUrl:String?
    var History:Int?
    var MinPay:String?
    var AvgScore:String?
    var ClickCount:Int?
    var IsCertificated:String?
    var IsBlocked:String?
    var Visible:Int?
    var AcceptRequest:Int?
}




