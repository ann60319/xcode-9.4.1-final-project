//
//  FilterPMViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/2.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class FilterPMViewController: UIViewController {

    var myCharacter:String = ""
    var myNameArray:[String] = [String]()
    var strWebFolder: String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/"
    @IBOutlet weak var txt風格: UITextField!
    @IBOutlet weak var txt地區: UITextField!
    
    @IBAction func seg尋找_ValueChanged(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            if let character = sender.titleForSegment(at: 0){
                myCharacter = character
                print(myCharacter)
            }
        }else if sender.selectedSegmentIndex == 1{
            if let character = sender.titleForSegment(at: 1){
                myCharacter = character
                print(myCharacter)
            }
        }
        
    }
    
    
    
    @IBAction func btn篩選(_ sender: UIBarButtonItem) {
        var photoType = txt風格.text!
        var location = txt地區.text!
        
        myNameArray.removeAll() //先拿掉原本所有的集合元素
        
        if myCharacter == "攝影師"{
            
            
            if location.count > 0 && photoType.count == 0 {
               
                let strWeb2: String = strWebFolder + "p/find?Location=\(location)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
                
            }else if location.count == 0 && photoType.count > 0{
                
                let strWeb2: String = strWebFolder + "p/find?PhotoType=\(photoType)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
                
            }else if location.count > 0 && photoType.count > 0{
                let strWeb2: String = strWebFolder + "p/find?PhotoType=\(photoType)&Location=\(location)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
            }
            
       
        }else if myCharacter == "模特兒"{
            
            if location.count > 0 && photoType.count == 0 {
                
                let strWeb2: String = strWebFolder + "m/find?Location=\(location)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
                
            }else if location.count == 0 && photoType.count > 0{
                
                let strWeb2: String = strWebFolder + "m/find?ModelRole=\(photoType)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
                
            }else if location.count > 0 && photoType.count > 0{
                let strWeb2: String = strWebFolder + "m/find?ModelRole=\(photoType)&Location=\(location)"
                UserDefaults.standard.set(strWeb2, forKey: "web_url")
                UserDefaults.standard.synchronize()
            }
        }
        
        //取出UserDefaults存的url
        if let strURL = UserDefaults.standard.value(forKey: "web_url") as? String{
            
            let strPerEscString: String = strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
            
            //建立連線物件
            let myURL = URL(string: strPerEscString)
            let mySessionConfig = URLSessionConfiguration.default
            let mySession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
            
            var myRequest = URLRequest(url: myURL!)
            myRequest.httpMethod = "GET"
            
            let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
                (data: Data?, response: URLResponse?, error: Error?) -> Void in
                if error == nil {
                    let statusCode = (response as! HTTPURLResponse).statusCode
                    print("http狀態碼:\(statusCode)")
                    print("共下載:\(data!.count) bytes")
                    
                    ////解析JSON
                    do {
                        let results:[String: Any] = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
                        
                        let resArray = results["data"] as! [[String:Any]]//拿到data的所有陣列值
                        
                        for showNamwDict in resArray{
                            let nameResult = showNamwDict["ShowName"] as! String
                            self.myNameArray.append(nameResult)
                            
                            UserDefaults.standard.set(self.myNameArray, forKey: "fiter_result")
                            UserDefaults.standard.synchronize()
                            print("============")
                            print(self.myNameArray)
                            
                            //建立跳轉變數
                            if let myVCFind: FindViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc篩選結果") as? FindViewController{
                                
                                //將篩選結果 傳遞到跳轉頁面
                                myVCFind.getFilterResult = self.myNameArray
                                
                                
                                print("<=========>有成功！")
                                //跳轉
                                self.present(myVCFind,animated: true, completion: nil)
                                //self.dismiss(animated: true, completion: nil)
                            }
  
                        }
                    }
                    catch {
                        print("解析錯誤:\(error)")
                    }
                } else {
                    print("錯誤:\(String(describing:error?.localizedDescription))")
                }
            })

        myDataTask.resume()
    }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
