    //
    //  SpotListController.swift
    //  PMToBe
    //
    //  Created by Yi Hwei Huang on 2018/10/11.
    //  Copyright © 2018 YiChun. All rights reserved.
    //

    import UIKit
    import MapKit
    import CoreLocation

    class SpotListController: UIViewController ,MKMapViewDelegate,CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{


    @IBOutlet weak var SearchBar: UISearchBar!
    @IBOutlet weak var btnZoomIn: UIBarButtonItem!
    @IBOutlet weak var btnZoomOut: UIBarButtonItem!
    @IBOutlet weak var mapView_SpotList: MKMapView!
    @IBOutlet weak var tableView: UITableView!
        
    //variables
    var mapScaleMeter:Double=1000.0
    var myLocationManager:CLLocationManager!
    
    //sigleton -> 全域變數
    let appDelegate:AppDelegate=UIApplication.shared.delegate as! AppDelegate
        
    var strSpotData:Data?
    var arraySpotName:[String] = []
    var arraySpotAddress:[String] = []
    var arraySpotDescription:[String] = []
    var arraySpotPosX:[String] = []
    var arraySpotPosY:[String] = []
    var arraySpotGUID:[String] = []
    var searchedSpot = [String]()
    var searching = false
    



    @IBAction func btnZoomIn_Click(_ sender: Any) {

        self.mapScaleMeter *= 1.5
        let userLocation:MKUserLocation=self.mapView_SpotList.userLocation
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(userLocation.coordinate, self.mapScaleMeter,self.mapScaleMeter )
        self.mapView_SpotList.setRegion(region, animated: false)
    }

    @IBAction func btnZoomOut_Click(_ sender: Any) {

        self.mapScaleMeter *= 2.5
        let userLocation:MKUserLocation=self.mapView_SpotList.userLocation
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(userLocation.coordinate, self.mapScaleMeter,self.mapScaleMeter )
        self.mapView_SpotList.setRegion(region, animated: false)

    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    let myLocation:CLLocation=locations.last!
    //        print("\(myLocation.coordinate.longitude)","\(myLocation.coordinate.latitude)")

    }


    func addLandmark(){

        for i in 0..<arraySpotPosY.count{
        let strPosY:String=arraySpotPosY[i]
        let doublePosY=(strPosY as NSString).doubleValue

        let strPosX:String=arraySpotPosX[i]
        let doublePosX=(strPosX as NSString).doubleValue

        print(doublePosX,"doublePosX")
        print(doublePosY,"doublePosY")
        //開始插旗子
        var myAutoFlag:CLLocationCoordinate2D=CLLocationCoordinate2D()
        myAutoFlag.longitude=doublePosX
        myAutoFlag.latitude=doublePosY
        print(myAutoFlag.latitude,"====myAutoFlag.latitude==")
        print(myAutoFlag.longitude,"=======myAutoFlag.longitude======")


        let myAutoFlagAnno:MKPointAnnotation = MKPointAnnotation()
        myAutoFlagAnno.coordinate=myAutoFlag
        myAutoFlagAnno.title=arraySpotName[i]
        print(myAutoFlagAnno.title!,"=====myAutoFlagAnno.title=======")


        self.mapView_SpotList.addAnnotation(myAutoFlagAnno)

        }

    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    if annotation is MKUserLocation
    {
        //user location style cannot change otherwise the program will froze
        //"is"-->是用來判斷是否是相同類別
        return nil
    }

    else
    {
    //     let annView:MKAnnotationView=MKAnnotationView(annotation: annotation, reuseIdentifier: "myannot")
        //
        //annView.canShowCallout=true
        //
        //let btnInfo:UIButton = UIButton(type: UIButtonType.infoLight)
        //
        //btnInfo.addTarget(self, action: #selector(showDetailView(_:)), for: UIControlEvents.touchUpInside)
        //annView.rightCalloutAccessoryView = btnInfo
        //
        //print("===get anno====")
        return nil
    }
}

    @IBAction func showDetailView(_ sender: Any) {
    print("~~~open~~~")
    }


    override func viewDidLoad() {
    super.viewDidLoad()

        //get request to get all spot list
        strSpotData=APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot")

        //parse json for the filed what we get in spot-list
        arraySpotName=APIFactory().parseAllSpotName(data: strSpotData!) as! [String]
        //        print(arraySpotName,"======spot name")

        arraySpotGUID=APIFactory().parseAllSpotGUID(data: strSpotData!) as! [String]
        //        print(arraySpotGUID,"======GUID")

        arraySpotPosX=APIFactory().parseAllSpotPosX(data: strSpotData!) as! [String]
        //        print(arraySpotPosX,"========spot PosX")

        arraySpotPosY=APIFactory().parseAllSpotPosY(data: strSpotData!) as! [String]
        //        print(arraySpotPosY,"======spot PosY")

        arraySpotAddress=APIFactory().parseAllSpotAddress(data: strSpotData!) as! [String]
        //        print(arraySpotAddress,"====spot address")

        arraySpotDescription=APIFactory().parseAllSpotDescription(data: strSpotData!) as! [String]
        //        print(arraySpotDescription,"======Description")





        self.myLocationManager=CLLocationManager()
        self.myLocationManager.delegate=self
        //best適合行人定位速度比較慢
        self.myLocationManager.desiredAccuracy=kCLLocationAccuracyBest
        self.myLocationManager.requestWhenInUseAuthorization()
        self.myLocationManager.requestAlwaysAuthorization()
        self.myLocationManager.startUpdatingLocation()

        self.mapView_SpotList.delegate=self
        self.mapView_SpotList.showsUserLocation=true

        self.tableView.delegate=self
        self.tableView.dataSource=self
        self.SearchBar.delegate=self
        

    }

    override func viewDidAppear(_ animated: Bool) {
        //插旗子方法
        self.addLandmark()
    }

    override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()

    }
    
        
    override var shouldAutorotate: Bool{
        return true
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return UIInterfaceOrientationMask.landscapeLeft
    }
        
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        //the screen lanscape mode
        if size.width>size.height{
            //實作打橫情況的talbe view
            
        }
    }

    //tableview
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellID:String="cell"
        //讓產生的cell可以重複使用
        var cell:UITableViewCell?=tableView.dequeueReusableCell(withIdentifier: cellID)
        //之前從沒產生cell
        if cell==nil{
            cell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: cellID)
        }
        
        else
        {
            cell!.textLabel?.text=self.arraySpotName[indexPath.row] as! String
            cell!.detailTextLabel!.text=self.arraySpotAddress[indexPath.row] as! String
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arraySpotName.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section==0{
            let theDetailVC:SpotDetailController=self.storyboard?.instantiateViewController(withIdentifier:"VCDetail") as! SpotDetailController
            theDetailVC.strAddress="\(arraySpotAddress[indexPath.row])"
            theDetailVC.strName="\(arraySpotName[indexPath.row])"
            theDetailVC.strDescription="\(arraySpotDescription[indexPath.row])"
            theDetailVC.strLat="\(arraySpotPosY[indexPath.row])"
            theDetailVC.strLon="\(arraySpotPosX[indexPath.row])"
            theDetailVC.strGUID="\(arraySpotGUID[indexPath.row])"
            self.navigationController?.show(theDetailVC, sender: nil)
        }
    }
      
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchedSpot = arraySpotName.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
        searching = true
        tableView.reloadData()
    }
    


        
        
        
        
        
        


}///end of spotlist-----
