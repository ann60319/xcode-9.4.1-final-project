//
//  ImageUploadViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/9/5.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth

class ImageUploadViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var uploadedImages = [[String:String]]() //存放 上傳的圖片集合
    var downloadImages = [String:UIImage]() //每次下載的UIImage就放在此Dictionary
//    var firebaseURL:String = ""
    
    //服從UICollectionViewDelegate 與 UICollectionViewDataSource 要實作以下兩個方法
    //有幾個cell
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return uploadedImages.count
    }
    
    //顯示cell內容的作法：從link下載data後 再改為image
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = sharedImagesCollection.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! ImageCollectionViewCell //轉型後才能回傳UICollectionViewCell
        
        //取得link
        if let linkString = uploadedImages[indexPath.row]["link"]{
            cell.image.image = downloadImages[linkString] //把image 顯示於畫面中
        }
        
        return cell
    }
    

    
    @IBOutlet weak var sharedImagesCollection: UICollectionView!
    
    @IBOutlet weak var uploadStatus: UIProgressView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //取得使用者Id
        if let loadId = UserDefaults.standard.value(forKey: "thisId") as? String{
            print("===========這是我ID======")
            print(loadId)
        }
        //取得使用者Name
        if let loadName = UserDefaults.standard.value(forKey: "thisUserName") as? String{
            print("===========這是我Name======")
            print(loadName)
        }
        
        
        // 不顯示進度條
        uploadStatus.isHidden = true
        
        //服從UICollectionViewDelegate, UICollectionViewDatasource
        sharedImagesCollection.delegate = self
        sharedImagesCollection.dataSource = self
        
        //載入時 取得Database
        let dataRef = Database.database().reference().child("pic")
        
        //圖片更新：第一次會把在Database中所有東西取出observeSingleEvent(of: .value)
        dataRef.observeSingleEvent(of: .value){ (snapshot) in
            
            //只要資料有異動 就先清空
            self.uploadedImages.removeAll()
            
            //把snapshot中的children倒出來
            for item in snapshot.children{
                
                if let itemSnapshot = item as? DataSnapshot{ //因型別是Any 故要轉型
                    
                    //注意：回傳的型別為Any 故要轉型
                    let uid = itemSnapshot.childSnapshot(forPath: "uid").value as! String
                    let link = itemSnapshot.childSnapshot(forPath: "link").value as! String
                    
                    let value = ["uid":uid,"link":link]
                    
                    if let imageUrl = URL.init(string: link){ //轉成URL
                        do{
                            let data = try Data.init(contentsOf: imageUrl) //由URL取得Data
                            if let image = UIImage(data: data){  //轉成image
                                self.downloadImages[link] = image
                            }
                            
                        }catch{
                            print(error.localizedDescription)
                        }
                    }
                    
                    self.uploadedImages.append(value) //將取得的uid跟link 裝進陣列中
                }
            }
            self.sharedImagesCollection.reloadData() //將UICollectionView重新讀取影像資料 用.reloadData()
        }
        
        //觀察 資料有新增才更新 用.observe(.childAdded)
        dataRef.observe(.childAdded) { (snapshot) in
            let uid = snapshot.childSnapshot(forPath: "uid").value as! String
            let link = snapshot.childSnapshot(forPath: "link").value as! String
            
            let value = ["uid":uid,"link":link]
            
            if let imageUrl = URL.init(string: link){ //轉成URL
                do{
                    let data = try Data.init(contentsOf: imageUrl) //由URL取得Data
                    if let image = UIImage(data: data){
                        self.downloadImages[link] = image
                    }
                    
                }catch{
                    print(error.localizedDescription)
                }
            }
            
            self.uploadedImages.append(value) //將取得的uid跟link 裝進陣列中
            
            self.sharedImagesCollection.reloadData() //將UICollectionView重新讀取影像資料 用.reloadData()
            
//            //通知訊息
//            let alert = UIAlertController.init(title: "有新資料", message: nil, preferredStyle: .alert)
//            alert.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
        }
    
    }
    
    ////照片上傳///////////
    @IBAction func uploadImage_Click(_ sender: UIButton) {
        
        let imagePicker = UIImagePickerController() //建立UIImagePickerController()
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary //資料來源：從照片圖庫
        imagePicker.allowsEditing = false //編輯功能關閉
        imagePicker.delegate = self //要服從UIImagePickerControllerDelegate,UINavigationControllerDelegate
        present(imagePicker, animated: true, completion: nil)//呈現
    }
    
    //UIImagePickerControllerDelegate 要實作取得照片後的方法 (會回傳info 裡面包含所有我們需要的東西)
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // 設定儲存位置 存在pic子目錄
        let storageRef = Storage.storage().reference().child("pic")
        
        // 從info中取得選取影像 並轉型為UIImage
        var image:UIImage?
        if let myImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            image = myImage
        }
        
        // 設定上傳檔案名
        var filename = "image.JPG"
        if let url = info[UIImagePickerControllerImageURL] as? URL{
            filename = url.lastPathComponent //url最後一個Component就是檔案名稱
        }
        
        // 取得目前使用者 ID
        if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
            if let data = UIImageJPEGRepresentation(image!, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
                
                //建立中介資料
                let myMetadata = StorageMetadata()
                
                myMetadata.contentType = "image/jpeg" //***轉為圖擋
                
                myMetadata.customMetadata = ["myKey":"myValue"] //可自訂metadata 將要的資訊設在Storage中
                
                uploadStatus.isHidden = false //上傳前顯示進度條
                
                //print(myMetadata)
                
                //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
                let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in //完成時會回傳: 真正完成的metadata跟Error
                    
                    self.uploadStatus.isHidden = true //上傳成功與否 都將進度條隱藏
                    
                    if  error == nil{
                        
                        //若上傳成功
                        let dataRef = Database.database().reference().child("pic")
                        //print(metadata)
                        
                        storageRef.child(theUid).child(filename).downloadURL(completion: {
                           
                            (url, error) in
                            
                            //print("\(url)--------")
                            if error != nil {
                                
                                return
                            } else {
                                
                                let url = url?.absoluteString //＊＊＊取得URL的字串
                                
                                let value = ["uid":theUid,"link":url]
                                
                                dataRef.childByAutoId().setValue(value)
                                
                                
                                UserDefaults.standard.set(url, forKey: "firebase_URL") //用UserDefaults將要POST到資料庫的url存進去
                                UserDefaults.standard.synchronize() //同步
                            }
                        })
                        
                        ///////寫入到Server///////////
                        //let user = Auth.auth().currentUser
                        
                        
                        let uploaderId = theUid
//                        var path:String?
//                        dataRef.observe(.childAdded) { (snapshot) in
//
//                            let link = snapshot.childSnapshot(forPath: "link").value as! String
//                            path = link
//                        }
                        
                        //用UserDefaults將要POST到資料庫的url取出
                        let firebaseURL = UserDefaults.standard.value(forKey: "firebase_URL") as! String
                        print("=====測試用firebaseURL：====")
                        print(firebaseURL)
                        
                        let postdata:[String: Any] = ["UploaderUid":uploaderId,"Path":firebaseURL] //注意：型別 與 欄位名稱 是否與資料庫一致

                        let url = URL(string: "http://Testpmtobe-env.cvxrvfa7jm.ap-northeast-1.elasticbeanstalk.com/api/UploadImageAPP") //用我寫的api

                        let config = URLSessionConfiguration.default
                        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                        var request = URLRequest(url: url!)

                        request.httpMethod = "POST"
                        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                        request.httpBody = httpbody

                        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in

                            if let response = response{
                                print("<===================>這是URLResponse：")
                                print(response)
                            }
                            if let data = data{
                                do{
                                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                                    print("<===================>這是json：")
                                    print(json)
                                }catch{
                                    print("<===================>這是error：")
                                    print(error)

                                }
                            }
                        })
                        dataTask.resume()
                        
                        
                 
                        

//                        let value = ["uid":theUid,"link":(metadata?.downloadURL())!.absoluteString]//(待查詢)link：存回傳的metadata中的下載位置
                        //dataRef.childByAutoId().setValue(value)
                        

                       
                        
                    }else{
                        //若上傳失敗 印出錯誤
                        print(error?.localizedDescription)
                    }
                }
                //進度顯示
                task.observe(.progress) { (snapshot) in //observe監聽整個過程 回傳一個snapshot
                    if let theProgress = snapshot.progress?.fractionCompleted{ //fractionCompleted完成百分比
                        self.uploadStatus.progress = Float(theProgress) //轉型為Float
                    }
                }
            }
        }
        picker.dismiss(animated: true, completion: nil) //將picker關閉
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
