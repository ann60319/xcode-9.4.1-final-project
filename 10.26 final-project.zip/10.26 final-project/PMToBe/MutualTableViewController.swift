//
//  MutualTableViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/25.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
//import Firebase
//import FirebaseDatabase

//struct User{
//    var name:String?
//    var district:String?
//    var score:Int?
//    var style: String?
//}


//struct AllData:Decodable {
//    var photographer: [SingleData]? //型別是陣列   注意：屬性名稱要跟JSON的key名稱要一樣  ex：都叫results
//}
//
//struct SingleData:Decodable {
//    var p1:P1?
//    var p2:P2?    //也要建立p2 struct??
//    var p3:P3?
//}
//
//struct P1:Decodable{
//    var name:String?
//    var district:String?
//    var score:Int?
//    var style:Style
//}

//struct Style {
//    var s1:String?
//    var s2:String?
//    var s3:String?
//}

class MutualTableViewController: UITableViewController { //搜尋互惠
   
    var loadName:[String] = [String]()
    var myArray:[String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let strURL:String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p"
        
        //建立方法回傳的字串 //此方法會將非ASCII的字元轉為ASCII
        let strPerEScURL:String = strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        ////////以下為標準流程///////(沒特別含意)
        let myURL:URL = URL(string: strPerEScURL)!
        let mySessionConfig:URLSessionConfiguration = URLSessionConfiguration.default
        let mySession:URLSession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        
        //向瀏覽器請求 使用GET方法
        var myRequest = URLRequest(url:myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data:Data?, response:URLResponse?, error:Error?) -> Void in
            
            if error == nil{
                let statusCode = (response as! HTTPURLResponse).statusCode
                
                print("http狀態碼:\(statusCode)") //註：回應的狀態碼：200為成功 403為找不到
                
                print("共下載:\(data!.count) bytes") //取的資料大小 因回傳資料在data緩衝區
                
                /////解析JSON
                do{
                    let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
                    
                    let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
                    
                    for showNamwDict in resArray{
                        
                        let nameResult = showNamwDict["ShowName"] as! String
                        self.myArray.append(nameResult)
                        print("============")
                        print(self.myArray)
                        
                        UserDefaults.standard.set(self.myArray, forKey: "all_name") //用set存進去的可能是任何型別 所以之後要取出要用optional binding
                        UserDefaults.standard.synchronize() //同步
                        
                    }
                    
                }catch{
                    print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
                }
                
                
            }else{
                print("錯誤:\(String(describing: error?.localizedDescription))")
            }
        })
        myDataTask.resume()
        
    }
    

 
    
    
//    //呼叫警告控制器
//    func popAlert(withTitle title:String){
//        let alert = UIAlertController(title: title, message: "訊息提示", preferredStyle: .alert)//建警告控制器
//        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil) //建立按鈕
//        alert.addAction(okAction) //將按鈕加到警告控制器中
//        present(alert,animated: true,completion: nil)
//    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var nameCount:Int = 0
        if let resultName =  UserDefaults.standard.value(forKey: "all_name") as? [String]{
            
            self.loadName = resultName
            print("=====有取到loadName")
            print(self.loadName)
            
            return loadName.count
        }
        
        return nameCount
        
        // #warning Incomplete implementation, return the number of rows
//        return userArray.count
    }

    //決定每個cell會顯示的資料
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()
        if let resultName =  UserDefaults.standard.value(forKey: "all_name") as? [String]{
            
            self.loadName = resultName
            print("=====有取到loadName")
            print(self.loadName)
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            if indexPath.section == 0{
                cell.textLabel?.text = loadName[indexPath.row]  //加問號是因UITableViewCell中的textLabel這個屬性是optional
            }else{
                cell.textLabel?.text = loadName[indexPath.row]
            }
            
            return cell
        }
        
        
        return cell
        
        
//        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) //是否有id名稱為Cell 將Cell回傳 並存進常數cell中
        
        //UITableViewCell都有屬性textLabel.text來顯示文字
//        cell.textLabel?.text = ""
        
//        cell.textLabel?.text = userArray[indexPath.row]
    }
    
    //用didSelectRowAt偵測使用者是否觸發
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetail", sender: nil) //performSegue確認要轉showDetail畫面
    }

    //轉場前會觸發prepare
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail"{
            if let dvc = segue.destination as? DetailViewController{//若成功轉型DetailViewController就存進dvc
                if let selectRow = tableView.indexPathForSelectedRow?.row{
                    
                    if let resultName =  UserDefaults.standard.value(forKey: "all_name") as? [String]{
                        self.loadName = resultName
                        
                        dvc.infofromViewOne = loadName[selectRow] //按下cell會將文字 傳到DetailViewController中
                    }
                    
                    
                }
            }
        }
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
