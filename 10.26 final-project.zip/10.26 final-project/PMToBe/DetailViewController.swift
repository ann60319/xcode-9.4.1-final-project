//
//  DetailViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/25.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var sharedImagesCollection: UICollectionView!
    
    var strDataPpic:Data? //攝影師作品Data
    var strDataMpic:Data? //模特兒作品Data
    var pPicArray:[String] = [] //攝影師作品
    var mPicArray:[String] = [] //模特兒作品
    
    var strData_PName:Data? //攝影師屬性Data
    var strData_MName:Data? //模特兒屬性Data
    var p風格:[String] = [] //攝影師風格
    var m風格:[String] = [] //模特兒風格
    var p電話:[String] = []
    var m電話:[String] = []
    var p地點:[String] = []
    var m地點:[String] = []
    @IBOutlet weak var myName: UILabel!
    @IBOutlet weak var lbl風格: UILabel!
    @IBOutlet weak var lbl電話: UILabel!
    @IBOutlet weak var lbl地點: UILabel!
    var infofromViewOne:String = ""
    var IndexfromViewOne:Int = 0 //選擇的index值
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myName.text = self.infofromViewOne //將所選的名稱由label顯示
        let apiFactory = APIFactory()
        sharedImagesCollection.delegate = self
        sharedImagesCollection.dataSource = self
        
        
        if appDelegate.strChooseCharacter == "攝影師"{
            if let loadPId = UserDefaults.standard.value(forKey: "PMId") as? String{
                
                print("===這些pid===",loadPId)
                strDataPpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadPId)")
                pPicArray = apiFactory.parse_Product(data: strDataPpic!) as! [String]
            }
            }else if appDelegate.strChooseCharacter == "模特兒"{
                
                if let loadMId = UserDefaults.standard.value(forKey: "PMId") as? String{
                    print("===這些mid===",loadMId)
                    strDataMpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadMId)")
                    mPicArray = apiFactory.parse_Product(data: strDataMpic!) as! [String]
                    
            }
        }
         
        
        
        ///傳送url///
        strData_PName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find") //攝影師所有屬性
        strData_MName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find") //攝影師所有屬性
        
        
        ///解析JSON///
        if appDelegate.strChooseCharacter == "攝影師"{            
            p風格 = apiFactory.parse_Pstyle(data: strData_PName!) as! [String]
            lbl風格.text = p風格[IndexfromViewOne]
            p電話 = apiFactory.parse_Pphone(data: strData_PName!) as! [String]
            lbl電話.text = p電話[IndexfromViewOne]
            p地點 = apiFactory.parse_Plocation(data: strData_PName!) as! [String]
            lbl地點.text = p地點[IndexfromViewOne]
            
            
            
            
        }else if appDelegate.strChooseCharacter == "模特兒"{
            m風格 = APIFactory().parse_Mstyle(data: strData_MName!) as! [String]
            lbl風格.text = m風格[IndexfromViewOne]
            m電話 = apiFactory.parse_Mphone(data: strData_MName!) as! [String]
            lbl電話.text = m電話[IndexfromViewOne]
            m地點 = apiFactory.parse_Mlocation(data: strData_MName!) as! [String]
            lbl地點.text = m地點[IndexfromViewOne]
        }
    }

    
    //實作以下兩個CollectionView的方法
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let nameCount:Int = 0
        
        if appDelegate.strChooseCharacter == "攝影師"{
            return pPicArray.count
        }else if appDelegate.strChooseCharacter == "模特兒"{
            return mPicArray.count
        }
        
        return nameCount
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = sharedImagesCollection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionViewCell
        
        if appDelegate.strChooseCharacter == "攝影師"{
            if let myImgaeURL: URL = URL(string: self.pPicArray[indexPath.row]){
                let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                cell.image.image = UIImage(data: myImageData)
            }
        }else if appDelegate.strChooseCharacter == "模特兒"{
            if let myImgaeURL: URL = URL(string: self.mPicArray[indexPath.row]){
                let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                cell.image.image = UIImage(data: myImageData)
            }
        }
 
//        cell.backgroundColor = UIColor.black
        
        
        return cell
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
