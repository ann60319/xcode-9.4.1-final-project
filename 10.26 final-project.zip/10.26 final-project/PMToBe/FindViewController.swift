//
//  FindViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/9/28.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class FindViewController: UIViewController,UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate {
    
    //宣告字串集合：以作為滾輪的資料來源
//    var arrayStyle:[String] = ["人物","婚紗","風景"]
//    var arrayLocation:[String] = ["台北,新北,桃園","台南"]
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var myCharacter:String = ""
    var strDataPName:Data?
    var strDataMName:Data?
    var strDataP_pic:Data?
    var strDataM_pic:Data?
    
    
    var getFilterResult:[String] = [String]()
    var pName:[String] = [] //攝影師姓名
    var mName:[String] = [] //模特兒姓名
    var profile_P:[String] = [] //攝影師大頭照
    var profile_M:[String] = [] //模特兒大頭照
    var pId:[String] = [] //攝影師Id
    var mId:[String] = [] //模特兒Id
    
    @IBAction func btnFilter_Click(_ sender: Any) {
        
        let myAlertController = UIAlertController(title: "請輸入篩選風格", message: "您確認要送出嗎？", preferredStyle: UIAlertControllerStyle.alert)
        
        //*** 加入風格、地區欄位:addTextField
        myAlertController.addTextField(configurationHandler: {
            (textField: UITextField)-> Void in  //閉包會傳入UITextField的參數 進來
            textField.placeholder = "請輸入風格" //placeholder為欄位提示字
            textField.tag = 0
        })
        
        myAlertController.addTextField(configurationHandler: {
            (textField: UITextField) ->Void in
            textField.placeholder = "輸入地點"
            textField.tag = 1
        })
        
        //OK按鈕
        let okAction = UIAlertAction(title: "確認送出", style: UIAlertActionStyle.destructive, handler: {
            (action) ->Void in
            
            //取得欄位的方式
            let myStyle = myAlertController.textFields?[0].text //取得帳號欄位的值 用textFields?[0]
            let myLocation = myAlertController.textFields?[1].text //取得密碼欄位的值 用textFields?[1]

            
            if self.myCharacter == "攝影師" && (myStyle?.count)! > 0 && (myLocation?.count)! == 0 {
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find") //攝影師姓名
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find?PhotoType=\(myStyle!)") //*字串插入值要加!
                sleep(1)
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                self.profile_P = APIFactory().parsePpic(data: self.strDataPName!) as! [String]
                self.myTableView.reloadData()
                
            }else if self.myCharacter == "攝影師" && (myStyle?.count)! == 0 && (myLocation?.count)! > 0{
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find") //攝影師姓名
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find?Location=\(myLocation!)")
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                self.profile_P = APIFactory().parsePpic(data: self.strDataPName!) as! [String]
                self.myTableView.reloadData()
                
            }else if self.myCharacter == "攝影師" && (myStyle?.count)! > 0 && (myLocation?.count)! > 0{
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find") //攝影師姓名
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                
                self.strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find?PhotoType=\(myStyle!)&Location=\(myLocation!)")
                sleep(1)
                self.pName = APIFactory().parseNameP(data: self.strDataPName!) as! [String]
                self.profile_P = APIFactory().parsePpic(data: self.strDataPName!) as! [String]
                self.myTableView.reloadData()
                
            }else if self.myCharacter == "模特兒" && (myStyle?.count)! > 0 && (myLocation?.count)! == 0{
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find") //模特兒姓名
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find?ModelRole=\(myStyle!)")
                sleep(1)
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                self.profile_M = APIFactory().parseMpic(data: self.strDataMName!) as! [String]
                self.myTableView.reloadData()
                
            }else if self.myCharacter == "模特兒" && (myStyle?.count)! == 0 && (myLocation?.count)! > 0{
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find") //模特兒姓名
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find?Location=\(myLocation!)")
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                self.profile_M = APIFactory().parseMpic(data: self.strDataMName!) as! [String]
                self.myTableView.reloadData()
                
            }else if self.myCharacter == "模特兒" && (myStyle?.count)! > 0 && (myLocation?.count)! > 0{
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find") //模特兒姓名
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                
                self.strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find?ModelRole=\(myStyle!)&Location=\(myLocation!)")
                sleep(1)
                self.mName = APIFactory().parseNameM(data: self.strDataMName!) as! [String]
                self.profile_M = APIFactory().parseMpic(data: self.strDataMName!) as! [String]
                self.myTableView.reloadData()
            }
            
        })
        
        //將按鈕加入訊息框中
        myAlertController.addAction(okAction)
        self.present(myAlertController, animated: true, completion: nil)

    }
    
    @IBOutlet weak var myTableView: UITableView!
    
    @IBAction func seg角色_ValueChanged(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            if let character = sender.titleForSegment(at: 0){
                myCharacter = character
                appDelegate.strChooseCharacter = character
                myTableView.reloadData()
                
                print("選了攝影師 已reloadData")
            }
        }else if sender.selectedSegmentIndex == 1{
            if let character = sender.titleForSegment(at: 1){
                myCharacter = character
                appDelegate.strChooseCharacter = character
                myTableView.reloadData()
                
                print("選了模特兒 已reloadData")
            }
        }
    }
    

    //TableView
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if myCharacter == "攝影師"{
            return pName.count
        }else if myCharacter == "模特兒"{
            return mName.count
        }else{
            return pName.count
        }
    }
    
    
    //每一列要顯示的資料
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()
        
        if myCharacter == "攝影師"{
            if let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? FindShowTableViewCell{
                
                    //如果轉型成功 就用客製化的cell顯示
                    cell.lblName.text = self.pName[indexPath.row]
                    
                if let myImgaeURL: URL = URL(string: self.profile_P[indexPath.row]){
                    let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                    cell.imageView?.image = UIImage(data: myImageData)
                }

                return cell
                
            }else{
                //如果轉型失敗 就用預設的cell顯示
                cell.textLabel?.text = pName[indexPath.row]
                
                if let myImgaeURL: URL = URL(string: profile_P[indexPath.row]){
                    let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                    cell.imageView?.image = UIImage(data: myImageData)
                }
                
                return cell
            }
            
        }else if myCharacter == "模特兒"{
            if let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)  as? FindShowTableViewCell{
                
                cell.lblName.text = self.mName[indexPath.row]
                
                if let myImgaeURL: URL = URL(string: self.profile_M[indexPath.row]){
                    let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                    cell.imageView?.image = UIImage(data: myImageData)
                }

                return cell
            }else{
                cell.textLabel?.text = mName[indexPath.row]
                
                if let myImgaeURL: URL = URL(string: profile_M[indexPath.row]){
                    let myImageData: Data = try! Data(contentsOf: myImgaeURL)
                    cell.imageView?.image = UIImage(data: myImageData)
                }
 
                return cell
            } 
        }
        return cell
        
    }
    
    //點擊儲存格
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        var loadID:String = "1"
        //點擊儲存格
        if indexPath.section == 0{
            
            if myCharacter == "攝影師"{
                loadID = pId[indexPath.row] //攝影師Id
                UserDefaults.standard.set(loadID, forKey: "PMId")
                UserDefaults.standard.synchronize()
                
                let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
                myVCDetail.infofromViewOne = "\(pName[indexPath.row])"
                myVCDetail.IndexfromViewOne = indexPath.row //將Index傳過去
                self.navigationController?.show(myVCDetail, sender: nil)
                
            }else if myCharacter == "模特兒"{
                
                loadID = mId[indexPath.row]//模特兒Id
                UserDefaults.standard.set(loadID, forKey: "PMId")
                UserDefaults.standard.synchronize()
                
                let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
                myVCDetail.infofromViewOne = "\(mName[indexPath.row])"
                myVCDetail.IndexfromViewOne = indexPath.row //將Index傳過去
                self.navigationController?.show(myVCDetail, sender: nil)
            }

        }else{

        }

    }
    

    
    //*** 覆寫viewWillAppear：每次回到前景就執行
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)//＊＊一定要執行父類別方法 以下在執行自己的

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ///傳送url///
        strDataPName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find") //攝影師姓名
        strDataMName = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m/find") //模特兒姓名

        sleep(1)
        
        ///解析JSON///
        pName = APIFactory().parseNameP(data: strDataPName!) as! [String]
        mName = APIFactory().parseNameM(data: strDataMName!) as! [String]
        profile_P = APIFactory().parsePpic(data: strDataPName!) as! [String]
        profile_M = APIFactory().parseMpic(data: strDataMName!) as! [String]
        
        pId = APIFactory().parse_Id(data: strDataPName!) as! [String]
        mId = APIFactory().parse_Id(data: strDataMName!) as! [String]
        print("==這是pid==",pId)
        
        myCharacter = "攝影師"
        appDelegate.strChooseCharacter = myCharacter
        
        myTableView.reloadData()
    }
  
 
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

   

}

