//
//  MyCollectionViewCell.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/10.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var image: UIImageView!
    
    
    
}
