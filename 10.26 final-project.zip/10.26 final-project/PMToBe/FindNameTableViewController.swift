//
//  FindNameTableViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/2.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class FindNameTableViewController: UITableViewController {

    var loadName:[String] = [String]()
    var myArray:[String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let strURL:String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p"
        
        //建立方法回傳的字串 //此方法會將非ASCII的字元轉為ASCII
        let strPerEScURL:String = strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        ////////以下為標準流程///////(沒特別含意)
        let myURL:URL = URL(string: strPerEScURL)!
        let mySessionConfig:URLSessionConfiguration = URLSessionConfiguration.default
        let mySession:URLSession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        
        //向瀏覽器請求 使用GET方法
        var myRequest = URLRequest(url:myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data:Data?, response:URLResponse?, error:Error?) -> Void in
            
            if error == nil{
                let statusCode = (response as! HTTPURLResponse).statusCode
                
                print("http狀態碼:\(statusCode)") //註：回應的狀態碼：200為成功 403為找不到
                
                print("共下載:\(data!.count) bytes") //取的資料大小 因回傳資料在data緩衝區
                
                /////解析JSON
                do{
                    let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
                    
                    let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
                    
                    for showNamwDict in resArray{
                        
                        let nameResult = showNamwDict["ShowName"] as! String
                        self.myArray.append(nameResult)
                        print("============")
                        print(self.myArray)
                        
                        UserDefaults.standard.set(self.myArray, forKey: "all_name") //用set存進去的可能是任何型別 所以之後要取出要用optional binding
                        UserDefaults.standard.synchronize() //同步
                        
                        
                        
                    }
                    
 
                    
                }catch{
                    print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
                }
                
                
            }else{
                print("錯誤:\(String(describing: error?.localizedDescription))")
            }
        })
        myDataTask.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var nameCount:Int = 0
        if let resultName =  UserDefaults.standard.value(forKey: "all_name") as? [String]{
            
            self.loadName = resultName
            print("=====有取到loadName")
            print(self.loadName)
            
            return loadName.count
        }
        
        return nameCount

    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        if let resultName =  UserDefaults.standard.value(forKey: "all_name") as? [String]{
            
            self.loadName = resultName
            print("=====有取到loadName")
            print(self.loadName)
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            if indexPath.section == 0{
                cell.textLabel?.text = loadName[indexPath.row]  //加問號是因UITableViewCell中的textLabel這個屬性是optional
            }else{
                cell.textLabel?.text = loadName[indexPath.row]
            }
            
            return cell
        }
        
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
